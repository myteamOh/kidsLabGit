package com.kidslab.teacher.registcourse.service;

import com.kidslab.teacher.registcourse.vo.RegistCourseVO;

public interface RegistCourseService {

	public int registCourseInsert(RegistCourseVO rvo);

}
