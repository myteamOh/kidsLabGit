package com.kidslab.teacher.registcourse.dao;

import com.kidslab.teacher.registcourse.vo.RegistCourseVO;

public interface RegistCourseDao {

	public int registCourseInsert(RegistCourseVO rvo);

}
